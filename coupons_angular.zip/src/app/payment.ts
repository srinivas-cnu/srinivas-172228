export class Payment {
    username:string;
    nameOnCard: string;
    creditCardNumber: string;
    expMonth: string;
    expYear: string;
    cvv: string;
    couponCode:string;
}

