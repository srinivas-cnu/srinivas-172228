export class Customer {
    id:    string;
    name:  string;
    email: string;
    uname: string;
    pass:  string;
}
