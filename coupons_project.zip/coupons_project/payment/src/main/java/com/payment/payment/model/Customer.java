package com.payment.payment.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection ="coupon")
public class Customer {

	@Id
	String id;
	String username;
	
	int CouponCode;
	
	
	String nameOnCard;
	String creditCardNumber;
	String expMonth;
	String expYear;
	String cvv;
	
	public Customer(String username, int couponCode, String nameOnCard, String creditCardNumber, String expMonth,
			String expYear, String cvv) {
		super();
		this.username = username;
		CouponCode = couponCode;
		this.nameOnCard = nameOnCard;
		this.creditCardNumber = creditCardNumber;
		this.expMonth = expMonth;
		this.expYear = expYear;
		this.cvv = cvv;
	}
	public Customer() {
		super();
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getCouponCode() {
		return CouponCode;
	}
	public void setCouponCode(int couponCode) {
		CouponCode = couponCode;
	}
	public String getNameOnCard() {
		return nameOnCard;
	}
	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}
	public String getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public String getExpMonth() {
		return expMonth;
	}
	public void setExpMonth(String expMonth) {
		this.expMonth = expMonth;
	}
	public String getExpYear() {
		return expYear;
	}
	public void setExpYear(String expYear) {
		this.expYear = expYear;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	
		
	
	
	
}
