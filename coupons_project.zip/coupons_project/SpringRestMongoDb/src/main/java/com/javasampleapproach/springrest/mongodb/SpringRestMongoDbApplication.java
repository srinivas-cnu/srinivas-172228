package com.javasampleapproach.springrest.mongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestMongoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestMongoDbApplication.class, args);
	}
}
